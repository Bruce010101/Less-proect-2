$(document).ready(function(){
$('.text-slider').slick({
  autoplay:true,
  autoplaySpeed: 2000,
  dots:false,
  arrows:true
});
});
